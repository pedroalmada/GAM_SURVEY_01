document.addEventListener('DOMContentLoaded', function() {
    // Function to toggle the display of 'Other' text input for roads
    function toggleOtherTextInputRoads() {
        const isOtherSelected = document.getElementById('roads_other').checked;
        const otherTextInput = document.getElementById('roads_other_text');
        otherTextInput.style.display = isOtherSelected ? 'block' : 'none';
    }

    // Function to toggle the display of 'Other' text input for activities
    function toggleOtherTextInputActivities() {
        const isOtherSelected = document.getElementById('activity_other').checked;
        const otherTextInput = document.getElementById('activity_other_text');
        otherTextInput.style.display = isOtherSelected ? 'block' : 'none';
    }

    // Initialize the display state of the 'Other' text inputs
    toggleOtherTextInputRoads();
    toggleOtherTextInputActivities();

    // Add event listeners to 'Other' options for roads and activities
    document.getElementById('roads_other').addEventListener('change', toggleOtherTextInputRoads);
    document.getElementById('activity_other').addEventListener('change', toggleOtherTextInputActivities);

    // Function to handle the "Anonymous" checkbox behavior
    document.getElementById('anonymous').addEventListener('change', function() {
        var isChecked = this.checked;
        var inputs = document.querySelectorAll('#fname, #email');
        inputs.forEach(function(input) {
            input.disabled = isChecked;
            if (isChecked) {
                input.value = '';
            }
        });
    });

     // Code for Date

    document.addEventListener('DOMContentLoaded', function() {
        var dateInput = document.getElementById('survey_date');
        var today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
    });
    

    // General function to manage "None" selections for checkboxes
    function setupNoneCheckboxHandlers(sectionName) {
        var checkboxes = document.querySelectorAll(`input[name="${sectionName}[]"]`);

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                if (this.id === `${sectionName}_none` && this.checked) {
                    checkboxes.forEach(cb => cb !== this ? cb.checked = false : null);
                } else if (this.checked) {
                    document.getElementById(`${sectionName}_none`).checked = false;
                }
            });
        });
    }

    // Setup "None" checkbox handlers for each section
    setupNoneCheckboxHandlers('buildings');
    setupNoneCheckboxHandlers('roads');
    setupNoneCheckboxHandlers('damage');
    setupNoneCheckboxHandlers('alterations');
    setupNoneCheckboxHandlers('remains');
    setupNoneCheckboxHandlers('activity');

    // Initialize Leaflet map
    console.log('Adjusting map styles', document.getElementById('map').style.height);


    var map = L.map('map').setView([20.6843, -88.5678], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: 'Map data © OpenStreetMap contributors'
    }).addTo(map);

    var marker;

    map.on('click', function(e) {
        if (marker) {
            map.removeLayer(marker);
        }
        marker = L.marker(e.latlng).addTo(map);
        document.getElementById('latitude').value = e.latlng.lat;
        document.getElementById('longitude').value = e.latlng.lng;
    });

    if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(function(position) {
            map.setView([position.coords.latitude, position.coords.longitude], 13);
            if (marker) map.removeLayer(marker);
            marker = L.marker([position.coords.latitude, position.coords.longitude]).addTo(map);
        });
    }
        // Other interactive elements initialization functions can be added here
});    
