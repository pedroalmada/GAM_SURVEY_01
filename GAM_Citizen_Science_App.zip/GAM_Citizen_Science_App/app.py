from flask import Flask, render_template, request, redirect, url_for
import csv
import os

app = Flask(__name__)

# Define the path to the CSV
file_path = 'surveys/survey_data.csv'
# Define the headers for the CSV file
headers = ['Name', 'Email', 'Age', 'Date', 'Latitude', 'Longitude', 'Buildings', 'Roads_and_Tracks', 'Damage', 'Human_Alterations', 'Archaeology', 'Human_Activity']

# Ensure the 'surveys' directory exists and the CSV file is initialized with headers
def init_csv():
    if not os.path.exists('surveys'):
        os.makedirs('surveys')
    if not os.path.isfile(file_path):
        with open(file_path, mode='w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()

# Call the init function
init_csv()


# Route for the welcome page
@app.route('/')
def welcome():
    return render_template('welcome_page.html')  

# Route for the survey page
@app.route('/survey')
def survey():
    return render_template('survey_Page.html')

@app.route('/submit_survey', methods=['POST'])
def submit_survey():
    print("Form Data:", request.form)  # To see raw form data
    anonymous = request.form.get('anonymous') == 'on'

    data = {
        'Name': 'Anonymous' if anonymous else request.form.get('fname', 'N/A'),
        'Email': 'Anonymous' if anonymous else request.form.get('email', 'N/A'),
        'Age': 'Anonymous' if anonymous else request.form.get('age', 'N/A'),
        'Date': request.form.get('survey_date', 'N/A'),
        'Latitude': request.form.get('latitude', 'N/A'),
        'Longitude': request.form.get('longitude', 'N/A'),
        'Buildings': ', '.join(request.form.getlist('buildings[]')),
        'Roads_and_Tracks': ', '.join(request.form.getlist('roads[]')),
        'Damage': ', '.join(request.form.getlist('damage[]')),
        'Human_Alterations': ', '.join(request.form.getlist('alterations[]')),
        'Archaeology': ', '.join(request.form.getlist('remains[]')),
        'Human_Activity': ', '.join(request.form.getlist('activity[]'))
    }

    print("Processed Data:", data)  # To see processed data ready to be saved

    with open(file_path, mode='a', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=headers)
        writer.writerow(data)

    return redirect(url_for('welcome'))


if __name__ == '__main__':
    app.run(debug=True) 